"""
Generates a synthetic MySQL-style sales table for a multi-region hardware
retailer, simulating what would normally sit in a real transactional DB.
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(7)

REGIONS = ["North", "South", "East", "West", "Central"]
PRODUCTS = [
    ("Power Drill", "Power Tools", 3200),
    ("Angle Grinder", "Power Tools", 2400),
    ("Hammer Set", "Hand Tools", 450),
    ("Screwdriver Kit", "Hand Tools", 350),
    ("Paint (10L)", "Paints", 1800),
    ("PVC Pipe (10ft)", "Plumbing", 220),
    ("Tap Fitting", "Plumbing", 380),
    ("LED Bulb Pack", "Electrical", 500),
    ("Extension Cord", "Electrical", 650),
    ("Cement Bag (50kg)", "Building Materials", 420),
]
region_factor = {"North": 1.3, "South": 1.1, "East": 0.85, "West": 1.2, "Central": 0.75}

start = datetime(2026, 1, 1)
n_days = 180
rows = []
for d in range(n_days):
    date = start + timedelta(days=d)
    month_growth = 1 + (d / n_days) * 0.25  # gentle upward trend over 6 months
    for region in REGIONS:
        n_txns = np.random.poisson(6 * region_factor[region] * month_growth)
        for _ in range(n_txns):
            name, category, price = PRODUCTS[np.random.randint(len(PRODUCTS))]
            qty = np.random.randint(1, 12)
            discount_pct = np.random.choice([0, 0, 0, 5, 10], p=[0.5, 0.2, 0.1, 0.1, 0.1])
            revenue = round(qty * price * (1 - discount_pct / 100), 2)
            rows.append({
                "order_date": date.strftime("%Y-%m-%d"),
                "region": region,
                "product": name,
                "category": category,
                "quantity": qty,
                "unit_price": price,
                "discount_pct": discount_pct,
                "revenue": revenue,
            })

df = pd.DataFrame(rows)
df.to_csv("sales_data.csv", index=False)
print(f"Generated {len(df):,} transactions from {start.date()} to {(start+timedelta(days=n_days-1)).date()}")
