# Automated Sales Reporting Dashboard — Smith Hardware

Replaces a manual, Excel-heavy monthly sales reporting process with an
automated ETL pipeline and a live dashboard, for a simulated multi-region
hardware retailer.

## What this does

1. **`generate_data.py`** — creates a synthetic transaction-level sales
   dataset (what would normally live in a MySQL sales table): 6 months of
   orders across 5 regions and 10 products.

2. **`etl_pipeline.py`** — the automation layer. It:
   - cleans the raw data (dedupes, drops invalid rows)
   - rolls transactions up into monthly revenue by region, category
     performance, and top products
   - calculates region-over-region growth from the first month to the
     latest month
   - writes everything a report needs into `dashboard_data.json`, so the
     dashboard never has to touch the raw transaction table

3. **`dashboard.html`** — standalone dashboard (just open it in a browser).
   Shows the monthly revenue trend, region and category breakdowns, top
   products, and a growth table — the numbers a regional manager used to
   wait a full reporting cycle to see.

## Run it yourself

```bash
pip install pandas
python3 generate_data.py
python3 etl_pipeline.py     # refreshes dashboard_data.json
```

Then open `dashboard.html` in any browser.

## Sample results (this run)

- Total revenue over 6 months: ₹3.79 Cr across 6,310 orders
- North was the top-performing region; Power Tools the top category
- East grew revenue ~40% from its first month to its last; Central declined ~11%
- Average order value: ₹6,012

## Tech used

Python, pandas for the ETL pipeline; Chart.js for the dashboard.

## Note on scope

In the real version of this project, `etl_pipeline.py` read from a live
MySQL database and Power BI Service handled the scheduled refresh. This repo
reproduces the same pipeline logic and output using a synthetic CSV in place
of the database connection, so the project can be run and inspected without
needing a real DB credential.
